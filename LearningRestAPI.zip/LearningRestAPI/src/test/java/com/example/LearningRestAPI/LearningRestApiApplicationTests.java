package com.example.LearningRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
