package com.example.LearningRestAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningRestApiApplication.class, args);
	}

}
